/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef PIKA-KMS-CLI_PRIVATE_H
#define PIKA-KMS-CLI_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"3.1.1.1"
#define VER_MAJOR	3
#define VER_MINOR	1
#define VER_RELEASE	1
#define VER_BUILD	1
#define COMPANY_NAME	""
#define FILE_VERSION	"3.1.1.1"
#define FILE_DESCRIPTION	"Ƥ����KMS��Ȩ����Setup"
#define INTERNAL_NAME	"Pikachuim KMS Authorization Tool"
#define LEGAL_COPYRIGHT	"Copyright 2019 Pikachuim"
#define LEGAL_TRADEMARKS	"Copyright 2019 Pikachuim"
#define ORIGINAL_FILENAME	"Ƥ����KMS��Ȩ����CLI"
#define PRODUCT_NAME	"Ƥ����KMS��Ȩ����CLI"
#define PRODUCT_VERSION	"3.1.1.1"

#endif /*PIKA-KMS-CLI_PRIVATE_H*/
